------------------------------------------------------------
MoFont Display v1.0
Designed by Michele Occhi
------------------------------------------------------------

DESCRIZIONE
MoFont è un carattere tipografico sperimentale. È un'opera derivata dal 
font "Sniglet" (di Haley Fiege), rielaborata per ottenere un 
impatto visivo più liquido.

LICENZA
Distribuito sotto licenza SIL Open Font License 1.1 (OFL).
Questo significa che puoi:
- Usarlo per progetti personali e commerciali.
- Studiarlo, modificarlo e ridistribuirlo (mantenendo la stessa licenza).

Non puoi:
- Vendere il file del font da solo.

CONTATTI & FEEDBACK
Se usi MoFont nei tuoi progetti, mi farebbe piacere vederlo, scrivimi

Web: https://micheleocchi.com
Mail: ciao@micheleocchi.design

------------------------------------------------------------
Grazie per aver scaricato MoFont!